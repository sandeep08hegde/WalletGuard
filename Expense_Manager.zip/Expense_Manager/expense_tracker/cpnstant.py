class classname:
    a=6
    b=3